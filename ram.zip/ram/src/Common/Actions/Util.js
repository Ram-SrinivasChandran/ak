export const Util = {
  cloneObject: (obj) => {
    return JSON.parse(JSON.stringify(obj));
  },
  isValidArray: (arrObj) => {
    return arrObj != undefined && arrObj != null && arrObj.length > 0;
  },
  isValidObject: (obj) => {
    return obj && obj !== "null" && obj !== "undefined";
  },
  isValidString: (obj) => {
    return (
      obj &&
      obj.length > 0 &&
      (typeof obj === "string" || obj instanceof String) &&
      obj.trim().length > 0
    );
  },
  isDateObject: (dateObj) => {
    return dateObj instanceof Date && !isNaN(dateObj);
  },
  isValidNumber: (obj) => {
    return obj && /^\d+$/.test(obj);
  },
  formatFileSize: (bytes, isSpeed) => {
    if (typeof bytes !== "number") {
      return "";
    }
    var GbSuffix = " GB";
    var MbSuffix = " MB";
    var KbSuffix = " KB";
    if (isSpeed) {
      GbSuffix = " Gbps";
      MbSuffix = " Mbps";
      KbSuffix = " Kbps";
    }

    if (bytes >= 1073741824) {
      return (bytes / 1073741824).toFixed(2) + GbSuffix;
    }

    if (bytes >= 1048576) {
      return (bytes / 1048576).toFixed(2) + MbSuffix;
    }

    return (bytes / 1024).toFixed(2) + KbSuffix;
  },
  getExtention: (fileName) => {
    return fileName.substr(fileName.lastIndexOf(".") + 1);
  },
  getCustomDateTimeFormat: (date) => {
    if (!date) {
      return;
    }
    date = new Date(date);
    const year = date.getFullYear(),
      month = date.toLocaleString("default", { month: "long" }),
      day = date.getDate(),
      hour = date.getHours(),
      minute = date.getMinutes(),
      minuteFormatted = minute < 10 ? "0" + minute : minute;

    return `${month} ${day}, ${year} ${hour}:${minuteFormatted}`;
  },
  setPageTitle: (headerText) => {
    let headerSpan = window.document.createElement("span");
    headerSpan.classList.add("head-txt");
    headerSpan.innerHTML = `| ${headerText}`;
    window.document.querySelector("#aGoHome").appendChild(headerSpan);
  },
  GroupBy: (array, f) => {
    var groups = {};
    array.forEach((o) => {
      var group = JSON.stringify(f(o));
      groups[group] = groups[group] || [];
      groups[group].push(o);
    });
    return Object.keys(groups).map((group) => {
      return groups[group];
    });
  },
  RemoveEmptyValues: (fieldname, value) => {
    let removeEntry = "";
    removeEntry = value
      ?.split(/[ ,]+/)
      .filter((v) => {
        return v !== "";
      })
      .join(",");
    return removeEntry;
  },

  RemoveEmptyAndNullValues: (fieldname, value) => {
    let removeEntryAndNull = "";
    removeEntryAndNull = value
      ?.split(/[ ,]+/)
      .filter((v) => {
        return v.toUpperCase() !== "NULL";
      })
      .join(",");
    return removeEntryAndNull;
  },

  sortOrder: (data) => {
    return data?.sort((a, b) => {
      if (a.Name.toUpperCase().trim() < b.Name.toUpperCase().trim()) return -1;
      if (a.Name.toUpperCase().trim() < b.Name.toUpperCase().trim()) return 1;
      return 0;
    });
  },

  getUniqueItems: (MasterItems) => {
    let uniqueItems = MasterItems?.filter(
      (ele, index) =>
        MasterItems?.findIndex((obj) => obj.Name === ele.Name) === index
    );
    let sortedItems = Util.sortOrder(uniqueItems);
    return sortedItems;
  },

  sanitizeURL: (url) => {
    var isValidUrl = true;
    var regEx = /(?:[\w-]+\.)+[\w-]+/g; //regex reference: https://regex101.com/r/aF1cY0/5
    var whitelistedDomain = ["exlservice.com"];

    var matched = url.match(regEx);
    if (matched != null && matched.length > 0) {
      for (var i = 0; i < matched.length; i++) {
        var isValidUrl = undefined;
        for (var j = 0; j < whitelistedDomain.length; j++) {
          if (matched[i].toLowerCase().indexOf(whitelistedDomain[j]) > 0) {
            isValidUrl = true;
            break;
          }
        }
        if (isValidUrl == undefined) {
          isValidUrl = false;
          alert(
            "Malicious url detected. Hence exceution aborted. Please contact support."
          );
          break;
        }
      }
    }
    return isValidUrl;
  },
};

export const GetLatestComments = (
  FNCTNL_ASSMNT,
  CMPRSN,
  COMMENTS,
  EFFCTNS_OF_CR
) => {
  return FNCTNL_ASSMNT + CMPRSN + COMMENTS + EFFCTNS_OF_CR;
};
