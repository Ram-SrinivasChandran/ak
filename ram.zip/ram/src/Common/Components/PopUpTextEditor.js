import React, { Component } from 'react'
import '../../css/PopUpTextEditor.css'

export class PopUpTextEditor extends Component {
  constructor() {
    super(...arguments)

    // default state declaration
    this.state = {
      parameter: {},
      headerText: '',
      searchData: '',
      inputData: '',
    }

    // bind methods
    this.updateValue = this.updateValue.bind(this)
    this.onEnterClick = this.onEnterClick.bind(this)
  }

  openEditor = (headerText, fieldValue, parameter) => {
    this.setState({ headerText: headerText, inputData: fieldValue, parameter })
    this.openPopUpBtn.click()
  }

  updateValue(e) {
    this.setState({ inputData: e.target.value })
  }

  onEnterClick = (e) => {
    if (e.keyCode === 13) {
      this.updateValue(e)
    }
  }

  // update the field value using callback function
  onSaveClick = () => {
    if (this.props.onValueUpdate) {
      this.props.onValueUpdate(this.state.parameter, this.state.inputData)
    }
  }

  // return dynamic content to UI
  render() {
    return (
      <>
        <button
          style={{ display: 'none' }}
          ref={(openPopUpBtn) => (this.openPopUpBtn = openPopUpBtn)}
          data-toggle="modal"
          data-backdrop="static"
          data-target={
            '#popUpTextEditor' +
            (this.props.popUpKey ? this.props.popUpKey : '')
          }
        >
          View More
        </button>
        <div
          id={
            'popUpTextEditor' + (this.props.popUpKey ? this.props.popUpKey : '')
          }
          className="modal fade custom-model"
          role="dialog"
        >
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <button type="button" className="close" data-dismiss="modal">
                  &times;
                </button>
                <h4 className="modal-title">{this.state.headerText}</h4>
              </div>
              {/* <div className="searchBox">
                            <form>
                                <input type="text" className="form-control" placeholder="Search" value={this.state.searchData} />
                            </form>
                        </div> */}
              <div className="modal-body">
                <textarea
                  type="textarea"
                  rows={15}
                  value={this.state.inputData}
                  onChange={this.updateValue}
                  onKeyPress={this.onEnterClick}
                />
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-primary"
                  data-dismiss="modal"
                >
                  Close
                </button>
                <button
                  type="submit"
                  className="btn btn-primary"
                  data-dismiss="modal"
                  onClick={this.onSaveClick}
                >
                  Apply
                </button>
              </div>
            </div>
          </div>
        </div>
      </>
    )
  }
}
