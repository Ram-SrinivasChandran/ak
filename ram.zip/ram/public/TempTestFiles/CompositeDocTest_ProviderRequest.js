function CompositeDocument() {
  return {
    IsReadOnlyMode: false,
    GridData: buildGridData(),

    MasterData: {
      CapDetails: [
        {
          ClientAuditProgramId: 15463,
          AuditProgramId: 15,
          AuditProgramName: "APC",
          ClientId: 100,
          ClientName: "AetnaACAS",
          POD: "Aetna",
          ClientAuditProgramName: "AetnaACAS - APC",
        },
        {
          ClientAuditProgramId: 1418,
          AuditProgramId: 16,
          AuditProgramName: "Home Health",
          ClientId: 1,
          ClientName: "Humana",
          POD: "Aetna",
          ClientAuditProgramName: "Humana - Home Health",
        },
        {
          ClientAuditProgramId: 15655,
          AuditProgramId: 1,
          AuditProgramName: "DRG",
          ClientId: 100,
          ClientName: "AetnaACAS",
          POD: "Aetna",
          ClientAuditProgramName: "AetnaACAS - DRG",
        },
        {
          ClientAuditProgramId: 15464,
          AuditProgramId: 2,
          AuditProgramName: "HBA",
          ClientId: 100,
          ClientName: "AetnaACAS",
          POD: "Aetna",
          ClientAuditProgramName: "AetnaACAS - HBA",
        },
        {
          ClientAuditProgramId: 15554,
          AuditProgramId: 15,
          AuditProgramName: "APC",
          ClientId: 99,
          ClientName: "AetnaHMO",
          POD: "Aetna",
          ClientAuditProgramName: "AetnaHMO - APC",
        },
        {
          ClientAuditProgramId: 15352,
          AuditProgramId: 1,
          AuditProgramName: "DRG",
          ClientId: 99,
          ClientName: "AetnaHMO",
          POD: "Aetna",
          ClientAuditProgramName: "AetnaHMO - DRG",
        },
        {
          ClientAuditProgramId: 15453,
          AuditProgramId: 2,
          AuditProgramName: "HBA",
          ClientId: 99,
          ClientName: "AetnaHMO",
          POD: "Aetna",
          ClientAuditProgramName: "AetnaHMO - HBA",
        },
        {
          ClientAuditProgramId: 15454,
          AuditProgramId: 15,
          AuditProgramName: "APC",
          ClientId: 96,
          ClientName: "AetnaHRP",
          POD: "Aetna",
          ClientAuditProgramName: "AetnaHRP - APC",
        },
        {
          ClientAuditProgramId: 15455,
          AuditProgramId: 1,
          AuditProgramName: "DRG",
          ClientId: 96,
          ClientName: "AetnaHRP",
          POD: "Aetna",
          ClientAuditProgramName: "AetnaHRP - DRG",
        },
        {
          ClientAuditProgramId: 13033,
          AuditProgramId: 2,
          AuditProgramName: "HBA",
          ClientId: 96,
          ClientName: "AetnaHRP",
          POD: "Aetna",
          ClientAuditProgramName: "AetnaHRP - HBA",
        },
        {
          ClientAuditProgramId: 10811,
          AuditProgramId: 15,
          AuditProgramName: "APC",
          ClientId: 82,
          ClientName: "BCBSMICom",
          POD: "Blues",
          ClientAuditProgramName: "BCBSMICom - APC",
        },
        {
          ClientAuditProgramId: 10810,
          AuditProgramId: 3,
          AuditProgramName: "DME",
          ClientId: 82,
          ClientName: "BCBSMICom",
          POD: "Blues",
          ClientAuditProgramName: "BCBSMICom - DME",
        },
      ],
      Statuses: [
        {
          Id: 1,
          Code: "NEW",
          Name: "New",
        },
        {
          Id: 2,
          Code: "UNRESOLVED",
          Name: "Unresolved",
        },
        {
          Id: 3,
          Code: "RESOLVED",
          Name: "Resolved",
        },
        {
          Id: 4,
          Code: "AUTORESOLVED",
          Name: "Auto Resolved",
        },
      ],
      RequestTypes: [
        {
          Id: 1,
          RequestTypeCode: "AUDITSTATUS",
          Name: "Audit Status",
          CanSelfAck: true,
          ParentId: 0,
          UserSkillset: null,
          IsAuthenticationRequired: true,
          DisplayOrder: 1,
          IsActive: true,
          ShowIn: "PORTAL/MINE",
        },
        {
          Id: 2,
          RequestTypeCode: "UPLOADSTATUS",
          Name: "Portal Record Upload Status",
          CanSelfAck: true,
          ParentId: 0,
          UserSkillset: null,
          IsAuthenticationRequired: true,
          DisplayOrder: 2,
          IsActive: true,
          ShowIn: "PORTAL/MINE",
        },
        {
          Id: 3,
          RequestTypeCode: "FAQ",
          Name: "FAQ's",
          CanSelfAck: true,
          ParentId: 0,
          UserSkillset: null,
          IsAuthenticationRequired: false,
          DisplayOrder: 3,
          IsActive: true,
          ShowIn: "PORTAL",
        },
        {
          Id: 1036,
          RequestTypeCode: "ACR",
          Name: "Address Change Request",
          CanSelfAck: false,
          ParentId: 0,
          UserSkillset: null,
          IsAuthenticationRequired: true,
          DisplayOrder: 4,
          IsActive: true,
          ShowIn: "MINE",
        },
        {
          Id: 1037,
          RequestTypeCode: "AQ",
          Name: "Appeal Query",
          CanSelfAck: false,
          ParentId: 0,
          UserSkillset: null,
          IsAuthenticationRequired: true,
          DisplayOrder: 5,
          IsActive: true,
          ShowIn: "MINE",
        },
        {
          Id: 1038,
          RequestTypeCode: "CQ",
          Name: "Clinical Query",
          CanSelfAck: false,
          ParentId: 0,
          UserSkillset: null,
          IsAuthenticationRequired: true,
          DisplayOrder: 6,
          IsActive: true,
          ShowIn: "MINE",
        },
        {
          Id: 1039,
          RequestTypeCode: "IQ",
          Name: "Invoice Query",
          CanSelfAck: false,
          ParentId: 0,
          UserSkillset: null,
          IsAuthenticationRequired: true,
          DisplayOrder: 7,
          IsActive: true,
          ShowIn: "MINE",
        },
        {
          Id: 1040,
          RequestTypeCode: "RKE",
          Name: "Reference Key Expired",
          CanSelfAck: false,
          ParentId: 0,
          UserSkillset: null,
          IsAuthenticationRequired: true,
          DisplayOrder: 8,
          IsActive: true,
          ShowIn: "MINE",
        },
        {
          Id: 1034,
          RequestTypeCode: "RRI",
          Name: "Record Receipt Inquiry",
          CanSelfAck: false,
          ParentId: 0,
          UserSkillset: null,
          IsAuthenticationRequired: true,
          DisplayOrder: 9,
          IsActive: true,
          ShowIn: "MINE",
        },
        {
          Id: 1035,
          RequestTypeCode: "OT",
          Name: "Other",
          CanSelfAck: false,
          ParentId: 0,
          UserSkillset: null,
          IsAuthenticationRequired: true,
          DisplayOrder: 10,
          IsActive: true,
          ShowIn: "MINE",
        },
      ],
      ChannelTypes: [
        {
          Code: "PHONE",
          Name: "Phone",
        },
        {
          Code: "PORTAL",
          Name: "Portal",
        },
        {
          Code: "EMAIL",
          Name: "Email",
        },
        {
          Code: "VOICEMAIL",
          Name: "VoiceMail",
        },
      ],

      RequestMode: ["Phone", "Portal", "EMail"],
    },
    SearchParameters: {
      Age: null,
      ToDate: new Date(),
      StatusIds: [1, 2],
      Channels: ["PHONE", "EMAIL"],
      FromDate: new Date(),
    },
  };
}

function buildGridData(rowsCount = 100) {
  var data;
  data = Array.from({ length: rowsCount }, (x, i) => ({
    Id: "123456" + i,
    CapName: "CapName" + i,
    Flow: "Flow" + i,
    AuditId: "" + i,
    RequestMode: "RequestMode" + i,
    RequestDate: GetFormattedDateTime(
      new Date(new Date().getTime() - i * 86400000)
    ).substr(0, 10),
    RequestTypeName: "RequestTypeName" + i,
    ChannelName: "Channel" + i + ", Channel" + (i + 1),
    CallerName: "CallerName" + i,
    StatusName: i % 2 == 0 ? "New" : i % 3 == 0 ? "Unresolved" : "Resolved",
    StatusCode: i % 2 == 0 ? "NEW" : i % 3 == 0 ? "UNRESOLVED" : "RESOLVED",
  }));

  return data;
}

GetFormattedDateTime = (date) => {
  let padValue = (value) => (value < 10 ? "0" + value : value);
  if (date) {
    var newDate = new Date(date);

    var sMonth = padValue(newDate.getMonth() + 1);
    var sDay = padValue(newDate.getDate());
    var sYear = newDate.getFullYear();
    var sHour = newDate.getHours();
    var sMinute = padValue(newDate.getMinutes());
    var sAMPM = "AM";

    var iHourCheck = parseInt(sHour);

    if (iHourCheck > 12) {
      sAMPM = "PM";
      sHour = iHourCheck - 12;
    } else if (iHourCheck === 0) {
      sHour = "12";
    }

    sHour = padValue(sHour);

    return (
      sMonth +
      "/" +
      sDay +
      "/" +
      sYear +
      " " +
      sHour +
      ":" +
      sMinute +
      " " +
      sAMPM
    );
  } else return "";
};
